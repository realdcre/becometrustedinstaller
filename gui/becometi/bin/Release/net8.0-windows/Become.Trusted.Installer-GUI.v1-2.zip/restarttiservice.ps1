cd C:\windows\servicing\
start-service trustedinstaller