echo off
Install-Module -Name NtObjectManager -RequiredVersion 1.1.20

